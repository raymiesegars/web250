<footer>
  &copy; <?php echo date('Y'); ?> Birds
</footer>

</body>
</html>

<?php
  db_disconnect($database);
?>
